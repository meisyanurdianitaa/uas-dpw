<?php $timeServices = app('App\Services\Timeservices'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="card mt-3 pt-3">
      <div class="row ml-1 mr-2 mb-3">
         <div class="col-md-12">
             <div class="float-right">
                    <b>Jam</b> <strong> <?php echo e($timeServices->showTimeNow()); ?></strong> 
                        </div>
            <h4>Filter</h4>
         </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('admin/produk/filter')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="" class="control-label">Nama produk</label>
                                <input type="text" class="form-control" name="nama" value="<?php echo e($nama ?? ""); ?>">
                            </div>

                            <div class="form-group">
                                <label for="" class="control-label">Stok</label>
                                <input type="text" class="form-control" name="stok" value="<?php echo e($stok ?? ""); ?>">
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="" class="control-label">Harga Min</label>
                                        <input type="text" class="form-control" name="harga_min" value="<?php echo e($harga_min ?? ""); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="" class="control-label">Harga Max</label>
                                        <input type="text" class="form-control" name="harga_max" value="<?php echo e($harga_max ?? ""); ?>">
                                    </div>
                                </div>
                            </div>

                            <button class="btn btn-dark float-right" ><i class="fa fa-search"></i> Filter</button>
                        </form>
                    </div>
                </div>


                <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
        <div class="col-md-8">
            <h4>Data Produk</h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo e(url('admin/produk/create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Tambah Data Produk</a>
        </div>
    </div>

    <div class="container">
        <table class="table">
            <thead>
                <th>No</th>
                <th>Aksi</th>
                <th>Nama</th>
                <th>Harga</th>
                <th>Brand</th>
                <th>Stok</th>
                <th>Tanggal</th>

            </thead>
                            <tbody>
                                <?php $__currentLoopData = $list_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(url('admin/produk', $produk->uuid)); ?>" class="btn btn-dark">
                                                    <i class="fa fa-info"></i>
                                                </a>
                                                <a href="<?php echo e(url('admin/produk', $produk->uuid)); ?>/edit" class="btn btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <?php echo $__env->make('template.utils.delete', ['url' => url('admin/produk', $produk->uuid)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </td>
                                        <td><?php echo e($produk->nama); ?></td>
                                        <td><?php echo e($produk->harga); ?></td>
                                        <td><?php echo e($produk->brand); ?></td>
                                        <td><?php echo e($produk->stok); ?></td>
                                        <td><?php echo e($produk->created_at->format("F j, Y, g:i a")); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\uas-dpw\system\resources\views/template/produk/index.blade.php ENDPATH**/ ?>