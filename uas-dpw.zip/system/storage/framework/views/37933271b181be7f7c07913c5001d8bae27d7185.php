<?php $__env->startSection('content'); ?>
<!-- start coding -->

   
   <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
      <h4>Detail Data Produk</h4>
    </div>

    <div class="container">
      <div class="card-body">
        <h3><?php echo e($produk->nama); ?></h3>
            <hr>
            <p><?php echo e($produk->harga); ?> |
   Brand : <?php echo e($produk->brand); ?> |
   Stok : <?php echo e($produk->stok); ?> |
   Seller : <?php echo e($produk->seller->username); ?> |
   Tanggal Produk : <?php echo e($produk->created_at->format("d M Y")); ?>

</p>
             <p>
                <?php echo nl2br ($produk->deskripsi); ?>

             </p>
            <p>
               <img src="<?php echo e(url("public/$produk->foto")); ?>" alt="<?php echo e($produk->foto); ?>" width="30%">
            </p>
        </div>  
      </div>
      
    </div>

    </div>
   </div>

<!-- end coding -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\uas-dpw\system\resources\views/template/produk/show.blade.php ENDPATH**/ ?>