<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
        <div class="col-md-8">
            <h4>Data User</h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo e(url('admin/user/create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Tambah User</a>
        </div>
    </div>
                    <div class="card-body">
                        <table class="table table-datatable">
                            <thead>
                                <th>No</th>
                                <th>Aksi</th>
                                <th>Username</th>
                                <th>Nama</th>
                                <th>Jenis_kelamin</th>
                                <th>Produk</th>
                                <th>Email</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $list_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                 <a href="<?php echo e(url('admin/user',$user->id)); ?>" class="btn btn-dark"><i class="fa fa-info"></i></a>
                                                 <a href="<?php echo e(url('admin/user',$user->id)); ?>/edit" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                                     <?php echo $__env->make('template.utils.delete', ['url' =>url('admin/user', $user->id)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </td>
                                        <td><?php echo e($user->username); ?></td>
                                        <td><?php echo e($user->nama); ?></td>
                                        <td><?php echo e($user->Jenis_Kelamin_String); ?></td>
                                        <td><?php echo e($user->product_count); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\Project15-dpw2\system\resources\views/template/user/index.blade.php ENDPATH**/ ?>