<form action="<?php echo e($url); ?>" class="form-inline" method="POST" onsubmit="return confirm('yakin menghapus data ini ?')">
  <?php echo csrf_field(); ?>
  <?php echo method_field("delete"); ?>
  <button class="btn btn-danger"><i class="fa fa-trash"></i></button>
</form><?php /**PATH C:\xampp\xampp\htdocs\uas-dpw\system\resources\views/template/utils/delete.blade.php ENDPATH**/ ?>