<?php

namespace App\Models;

class Checkout extends Model{
	protected $table = 'checkout';
}