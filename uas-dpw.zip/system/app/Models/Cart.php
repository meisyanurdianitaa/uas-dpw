<?php
namespace App\Models;

class Cart extends Model{

  protected $table = 'cart';
  

}