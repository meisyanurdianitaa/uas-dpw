@extends('client.section.base')

@section('content_front')



<body>
    <!-- Start Top Nav -->
    @include('client.section.navbar')
    <!-- Close Header -->

    



   


    <!-- Start Footer -->
  @include('client.section.footer')
    <!-- End Footer -->

    
</body>

</html>