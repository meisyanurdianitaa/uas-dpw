@extends('template.base')

@section('content')
 <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
        <div class="col-md-8">
            <h4>HALAMAN BERANDA</h4>
        </div>
        <div class="card-body">

        </div>
      </div>
    </div>
  </div>
@endsection